local ctx = require"_openssl.digest"

return ctx
