-- for backwards compatibility
return require "openssl.pkey"
