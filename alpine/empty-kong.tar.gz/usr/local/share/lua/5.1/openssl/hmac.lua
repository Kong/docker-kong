local ctx = require"_openssl.hmac"

return ctx
