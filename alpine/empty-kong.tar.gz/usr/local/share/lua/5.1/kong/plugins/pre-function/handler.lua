return require("kong.plugins.pre-function._handler")("pre-function", math.huge)
