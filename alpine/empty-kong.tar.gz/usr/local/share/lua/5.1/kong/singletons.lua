local _M = {
  configuration = nil,
  dao = nil,
  db = nil,
  dns = nil,
  worker_events = nil,
  router = nil,
}

return _M
